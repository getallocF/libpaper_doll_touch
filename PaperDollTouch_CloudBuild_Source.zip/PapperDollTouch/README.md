# PaperDollTouch — LeviLauncher Android native mod (ARM64)

## Honest status

This is a **source project with a cloud-build workflow**, not a finished working paper-doll mod. The supplied project does not include `libminecraftpe.so` from Minecraft 26.60, and the function signature and player field offsets have not been verified. In `config/config.json`, `verifiedSignaturesReady` therefore remains `false`. The built library is intended to load in fail-safe diagnostic mode; it will **not rotate the inventory paper doll yet**.

Do not set `verifiedSignaturesReady` to `true` by guessing values. The current render-function argument layout and `LocalPlayer` field offsets need to be checked against the actual Minecraft 26.60 binary and then tested in-game. A correct CPU architecture alone does not prove that the mod works.

## Target and packaging

- Launcher: LeviLauncher Android / LeviLaunchroid.
- Target ABI: `arm64-v8a`.
- Requested Minecraft build: `26.60`.
- Native entry library: `libpaper_doll_touch.so`.
- Package: `PaperDollTouch.levipack`.
- SDK: official `LiteLDev/preloader-android`, pinned to tag `0.2.3`.

The manifest uses `type: preload-native`, as required by the official native-mod guide.

## Build from an Android phone

Read `MULAI_DI_HP.txt`. It explains how to send this source project to GitHub from Termux and run the `.github/workflows/build.yml` workflow. The cloud job installs an Android NDK, builds only `arm64-v8a`, checks the ELF machine type with `file`/`readelf`, and packages the output as a `.levipack`.

A green GitHub Actions result proves only that the diagnostic build compiled and passed the packaging checks. It does not prove that paper-doll rotation works.

## Official references

- Native Mod Quick Start: https://docs.levimc.org/LeviLaunchroid/guide/developer
- Input API: https://docs.levimc.org/LeviLaunchroid/api/input
- Hook API: https://docs.levimc.org/LeviLaunchroid/api/hook
- Signature API: https://docs.levimc.org/LeviLaunchroid/api/signature
- SDK: https://github.com/LiteLDev/preloader-android
