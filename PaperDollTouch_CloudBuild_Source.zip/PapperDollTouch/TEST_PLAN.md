# TEST PLAN — PaperDollTouch

## Status before testing
The provided project does **not** currently contain verified Minecraft 26.60 function signatures or LocalPlayer field offsets. `verifiedSignaturesReady` must stay `false` until those values are independently verified. The build is therefore a diagnostic/fail-safe build and does not yet implement working paper-doll rotation.

## Build checks
1. Build through Android NDK for `arm64-v8a`.
2. Run `file libpaper_doll_touch.so`; expected output must mention `ELF 64-bit` and `ARM aarch64`.
3. Run `readelf -h libpaper_doll_touch.so`; `Machine` must be `AArch64`.
4. Check the `.levipack` ZIP listing. `manifest.json` and `libpaper_doll_touch.so` must be at the archive root, and both config files must be under `config/`.
5. Confirm launcher loads the mod without crashing. This only tests packaging/lifecycle, not paper-doll behavior.

## Functional checks required after signatures are verified
- Inventory opens/closes without crash.
- Drag on the preview changes only preview orientation.
- Dragging slots/buttons continues to work.
- Player camera/movement in the world is unchanged.
- Releasing touch ends gesture cleanly.
- Disable/unload returns the game to normal.
- Compare FPS and responsiveness against an identical no-mod baseline.

Record each test as `PASS`, `FAIL`, or `NOT TESTED`. Never mark a test `PASS` unless it was actually run.
