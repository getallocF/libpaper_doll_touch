# Build and install guide

## Important before building

The current source does not include a verified hook signature or verified field offsets for Minecraft 26.60. The configuration intentionally sets `verifiedSignaturesReady` to `false`. Therefore the output is a fail-safe diagnostic package, not the requested functional rotation feature. Do not enable the hook by filling in guessed numbers.

## Recommended build when using only an Android phone

Follow `MULAI_DI_HP.txt`. The build runs on GitHub Actions, so your phone only needs a browser and Termux. A PC is not required.

## What a successful cloud build should create

- `libpaper_doll_touch.so`
- `PaperDollTouch.levipack`
- `readelf-header.txt`, for the architecture check
- `package-list.txt`, for the package-content check
- `IMPORTANT.txt`, which explains the diagnostic-only status

In the Actions log, `file libpaper_doll_touch.so` must report an ELF 64-bit ARM AArch64 shared object. `readelf -h` must show `Machine: AArch64`.

## Install only for a load test

1. Download the `PaperDollTouch-Android-arm64v8a` artifact from the successful GitHub Actions run.
2. Extract the downloaded artifact ZIP. Inside it, find `PaperDollTouch.levipack`.
3. Import the `.levipack` using LeviLauncher Android's native-mod import flow.
4. Test in a backed-up or isolated Minecraft instance first.
5. If the game crashes, disable/remove the mod and check the launcher log.

Because signatures are not verified, this test only checks whether the package loads. It does not test the paper-doll rotation feature.
