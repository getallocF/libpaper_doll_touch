<#
.SYNOPSIS
    Build script resmi untuk PaperDollTouch (LeviLauncher Android Native Mod - arm64-v8a).
.DESCRIPTION
    Mengonfigurasi CMake dengan Android NDK, mengompilasi libpaper_doll_touch.so,
    dan mengemas hasilnya menjadi PaperDollTouch.levipack.
#>

param(
    [string]$Configuration = "Release",
    [string]$AndroidAbi = "arm64-v8a",
    [int]$AndroidPlatform = 28,
    [string]$NdkPath = $env:ANDROID_NDK_HOME,
    [string]$PreloaderSdkDir = ""
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$BuildDir = Join-Path $ProjectRoot "build\$AndroidAbi"
$DistDir = Join-Path $ProjectRoot "dist"
$PackageStagingDir = Join-Path $BuildDir "levipack_staging"

Write-Host "=== [1/5] Memeriksa Toolchain Android NDK ===" -ForegroundColor Cyan

if ([string]::IsNullOrWhiteSpace($NdkPath)) {
    $NdkPath = $env:ANDROID_NDK_ROOT
}

if ([string]::IsNullOrWhiteSpace($NdkPath) -or -not (Test-Path $NdkPath)) {
    throw "ANDROID_NDK_HOME tidak ditemukan. Tetapkan environment variable ANDROID_NDK_HOME atau berikan parameter -NdkPath."
}

$ToolchainFile = Join-Path $NdkPath "build\cmake\android.toolchain.cmake"
if (-not (Test-Path $ToolchainFile)) {
    throw "File toolchain CMake tidak ditemukan di: $ToolchainFile"
}

Write-Host "Menggunakan Android NDK: $NdkPath" -ForegroundColor Green

Write-Host "=== [2/5] Memeriksa SDK preloader-android ===" -ForegroundColor Cyan

if ([string]::IsNullOrWhiteSpace($PreloaderSdkDir)) {
    $PreloaderSdkDir = Join-Path $ProjectRoot "sdk\preloader-android"
}

$PreloaderInclude = Join-Path $PreloaderSdkDir "include"
if (-not (Test-Path $PreloaderInclude)) {
    Write-Host "Mengunduh header preloader-android resmi dari GitHub LiteLDev/preloader-android..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $PreloaderSdkDir) | Out-Null
    git clone --depth 1 --branch 0.2.3 https://github.com/LiteLDev/preloader-android.git $PreloaderSdkDir
}

Write-Host "=== [3/5] Mengonfigurasi CMake ($AndroidAbi) ===" -ForegroundColor Cyan

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null

cmake -S $ProjectRoot -B $BuildDir `
    -G "Ninja" `
    -DCMAKE_TOOLCHAIN_FILE="$ToolchainFile" `
    -DANDROID_ABI="$AndroidAbi" `
    -DANDROID_PLATFORM="android-$AndroidPlatform" `
    -DCMAKE_BUILD_TYPE="$Configuration" `
    -DPRELOADER_SDK_DIR="$PreloaderSdkDir"

if ($LASTEXITCODE -ne 0) {
    throw "Konfigurasi CMake gagal dengan kode keluar $LASTEXITCODE."
}

Write-Host "=== [4/5] Mengompilasi libpaper_doll_touch.so ===" -ForegroundColor Cyan

cmake --build $BuildDir --config $Configuration --parallel

if ($LASTEXITCODE -ne 0) {
    throw "Kompilasi gagal dengan kode keluar $LASTEXITCODE."
}

$SoFile = Join-Path $BuildDir "libpaper_doll_touch.so"
if (-not (Test-Path $SoFile)) {
    throw "Output libpaper_doll_touch.so tidak ditemukan di $SoFile"
}

Write-Host "=== [5/5] Membuat Paket PaperDollTouch.levipack ===" -ForegroundColor Cyan

if (Test-Path $PackageStagingDir) {
    Remove-Item -Recurse -Force $PackageStagingDir
}
New-Item -ItemType Directory -Force -Path $PackageStagingDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $PackageStagingDir "config") | Out-Null
New-Item -ItemType Directory -Force -Path $DistDir | Out-Null

Copy-Item -Path $SoFile -Destination (Join-Path $PackageStagingDir "libpaper_doll_touch.so") -Force
Copy-Item -Path (Join-Path $ProjectRoot "manifest.json") -Destination (Join-Path $PackageStagingDir "manifest.json") -Force
Copy-Item -Path (Join-Path $ProjectRoot "config\config.json") -Destination (Join-Path $PackageStagingDir "config\config.json") -Force
Copy-Item -Path (Join-Path $ProjectRoot "config\config.schema.json") -Destination (Join-Path $PackageStagingDir "config\config.schema.json") -Force

$DistSoPath = Join-Path $DistDir "libpaper_doll_touch.so"
$ZipTempPath = Join-Path $DistDir "PaperDollTouch.zip"
$LevipackPath = Join-Path $DistDir "PaperDollTouch.levipack"

Copy-Item -Path $SoFile -Destination $DistSoPath -Force
if (Test-Path $ZipTempPath) { Remove-Item -Force $ZipTempPath }
if (Test-Path $LevipackPath) { Remove-Item -Force $LevipackPath }

Compress-Archive -Path "$PackageStagingDir\*" -DestinationPath $ZipTempPath -Force
Move-Item -Path $ZipTempPath -Destination $LevipackPath -Force

Write-Host "Build selesai!" -ForegroundColor Green
Write-Host "Shared Library : $DistSoPath" -ForegroundColor Green
Write-Host "Paket Mod      : $LevipackPath" -ForegroundColor Green
