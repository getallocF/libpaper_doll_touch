#pragma once

#include <atomic>
#include <cstdint>
#include <string>

namespace paperdoll {

// Struktur area persegi dari UIControl internal Minecraft Bedrock (RectangleArea)
struct McRectangleArea {
    float x0{0.0f};
    float x1{0.0f};
    float y0{0.0f};
    float y1{0.0f};
};

// Konfigurasi yang dimuat satu kali pada fase load()
struct ModConfig {
    bool enabled{true};
    float sensitivityYaw{0.45f};
    float sensitivityPitch{0.30f};
    bool invertVertical{false};
    float maxPitchDegrees{45.0f};
    bool resetOnInventoryClose{true};
    float smoothingFactor{0.35f};

    // Fallback batas ternormalisasi [0.0, 1.0] jika UI bounds dinamis belum tersedia
    float normMinX{0.24f};
    float normMinY{0.14f};
    float normMaxX{0.44f};
    float normMaxY{0.56f};

    // Parameter verifikasi build 26.60 (wajib terverifikasi sebelum hook diaktifkan)
    std::string expectedMinecraftVersion{"26.60"};
    bool verifiedSignaturesReady{false};
    std::string hudPlayerRendererRenderSig{};
    std::string getLocalPlayerFromClientSig{};
    std::uintptr_t actorRotYawOffset{0};
    std::uintptr_t actorRotPitchOffset{0};
    std::uintptr_t mobBodyYawOffset{0};
    std::uintptr_t mobHeadYawOffset{0};
};

// State bebas-alokasi (lock-free atomic) untuk komunikasi Input Thread <-> Render Thread
struct RuntimeTouchState {
    std::atomic<bool> modActive{false};
    std::atomic<bool> hookInstalled{false};
    std::atomic<bool> inventoryPreviewVisible{false};

    // Timestamp frame terakhir saat HudPlayerRenderer inventory merender (ms monotonic)
    std::atomic<std::int64_t> lastInventoryRenderMs{0};

    // Pointer tracking agar jari yang mulai di slot item tidak memicu rotasi paper doll
    std::atomic<std::int32_t> activePointerId{-1};
    std::atomic<float> lastTouchX{0.0f};
    std::atomic<float> lastTouchY{0.0f};

    // Dimensi layar fisik yang terkalibrasi dari event input / window
    std::atomic<float> screenWidth{2400.0f};
    std::atomic<float> screenHeight{1080.0f};

    // Batas area preview dalam koordinat ternormalisasi [0.0, 1.0]
    std::atomic<float> activeBoundsMinX{0.24f};
    std::atomic<float> activeBoundsMinY{0.14f};
    std::atomic<float> activeBoundsMaxX{0.44f};
    std::atomic<float> activeBoundsMaxY{0.56f};

    // Target dan nilai saat ini untuk orientasi paper doll (dalam derajat)
    std::atomic<float> targetYawOffset{0.0f};
    std::atomic<float> targetPitchOffset{0.0f};
    std::atomic<float> currentYawOffset{0.0f};
    std::atomic<float> currentPitchOffset{0.0f};
};

class PaperDollTouchMod {
public:
    PaperDollTouchMod() = default;
    ~PaperDollTouchMod() = default;

    PaperDollTouchMod(const PaperDollTouchMod&) = delete;
    PaperDollTouchMod& operator=(const PaperDollTouchMod&) = delete;

    // Lifecycle standar Preloader Android / LeviLaunchroid
    bool load();
    bool enable();
    bool disable();
    bool unload();

    // Handler sentuhan yang dipanggil dari callback Input API
    // Mengembalikan false agar tidak pernah memblokir event UI/inventory asli Minecraft
    bool onTouchEvent(int action, int pointerId, float x, float y) noexcept;

    // Dipanggil dari detour HudPlayerRenderer::render pada Render Thread
    void onHudPlayerRenderDetour(
        void* self,
        void* renderContext,
        void* clientInstance,
        void* uiControl,
        int pass,
        McRectangleArea* rectArea
    ) noexcept;

    static PaperDollTouchMod& instance() noexcept;

private:
    bool loadConfiguration(const std::string& configPath) noexcept;
    bool tryInstallVerifiedHooks() noexcept;
    void removeHooks() noexcept;
    void resetTouchAndOrientation(bool clearAngles) noexcept;
    bool isPointInsidePreviewBounds(float x, float y) const noexcept;

    static std::int64_t monotonicMillis() noexcept;

    ModConfig mConfig{};
    RuntimeTouchState mState{};

    void* mHudPlayerRenderTarget{nullptr};
    void* mHudPlayerRenderOriginal{nullptr};
    void* mGetLocalPlayerFn{nullptr};
    bool mInputCallbackRegistered{false};
};

} // namespace paperdoll
