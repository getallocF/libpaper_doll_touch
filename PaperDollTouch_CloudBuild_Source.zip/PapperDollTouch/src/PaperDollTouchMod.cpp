#include "PaperDollTouchMod.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <time.h>
#include <fstream>
#include <filesystem>
#include <sstream>

#include <android/input.h>
#include <android/log.h>

// Deteksi keberadaan header Preloader Android SDK resmi
#if __has_include(<pl/Mod.hpp>)
    #include <pl/Mod.hpp>
    #define PDT_HAS_PL_MOD 1
#else
    #define PDT_HAS_PL_MOD 0
#endif

#if __has_include(<pl/Input.hpp>)
    #include <pl/Input.hpp>
    #define PDT_HAS_PL_INPUT 1
#else
    #define PDT_HAS_PL_INPUT 0
#endif

#if __has_include(<pl/memory/Hook.hpp>)
    #include <pl/memory/Hook.hpp>
    #define PDT_HAS_PL_HOOK 1
#else
    #define PDT_HAS_PL_HOOK 0
#endif

#if __has_include(<pl/memory/Signature.hpp>)
    #include <pl/memory/Signature.hpp>
    #define PDT_HAS_PL_SIG 1
#elif __has_include(<pl/Signature.hpp>)
    #include <pl/Signature.hpp>
    #define PDT_HAS_PL_SIG 1
#else
    #define PDT_HAS_PL_SIG 0
#endif

#define PDT_LOG_TAG "PaperDollTouch"
#define PDT_LOGI(fmt, ...) __android_log_print(ANDROID_LOG_INFO, PDT_LOG_TAG, fmt, ##__VA_ARGS__)
#define PDT_LOGW(fmt, ...) __android_log_print(ANDROID_LOG_WARN, PDT_LOG_TAG, fmt, ##__VA_ARGS__)
#define PDT_LOGE(fmt, ...) __android_log_print(ANDROID_LOG_ERROR, PDT_LOG_TAG, fmt, ##__VA_ARGS__)

namespace paperdoll {

namespace {

// Tipe fungsi asli HudPlayerRenderer::render pada arsitektur AArch64 (arm64-v8a)
using HudPlayerRendererRenderFn = void (*)(
    void* self,
    void* renderContext,
    void* clientInstance,
    void* uiControl,
    int pass,
    McRectangleArea* rectArea
);

// Tipe fungsi helper untuk memperoleh pointer LocalPlayer* dari IClientInstance*
using GetLocalPlayerFn = void* (*)(void* clientInstance);

// Batas waktu (ms) untuk menganggap layar inventory masih terbuka sejak frame render terakhir
constexpr std::int64_t kInventoryRenderTimeoutMs = 150;

// Batas minimum ukuran area RectangleArea agar paper doll HUD kecil (pojok kiri atas)
// tidak tertukar dengan paper doll layar inventory
constexpr float kMinInventoryPreviewWidthUi = 28.0f;
constexpr float kMinInventoryPreviewHeightUi = 40.0f;

// Helper pembaca nilai dari JSON sederhana tanpa library berat atau exception
bool extractJsonBool(const std::string& json, const char* key, bool& outVal) noexcept {
    std::string pattern = std::string("\"") + key + "\"";
    auto pos = json.find(pattern);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos + pattern.size());
    if (pos == std::string::npos) return false;
    auto valStart = json.find_first_not_of(" \t\r\n", pos + 1);
    if (valStart == std::string::npos) return false;
    if (json.compare(valStart, 4, "true") == 0) {
        outVal = true;
        return true;
    }
    if (json.compare(valStart, 5, "false") == 0) {
        outVal = false;
        return true;
    }
    return false;
}

bool extractJsonFloat(const std::string& json, const char* key, float& outVal) noexcept {
    std::string pattern = std::string("\"") + key + "\"";
    auto pos = json.find(pattern);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos + pattern.size());
    if (pos == std::string::npos) return false;
    auto valStart = json.find_first_not_of(" \t\r\n", pos + 1);
    if (valStart == std::string::npos) return false;
    char* endPtr = nullptr;
    float parsed = std::strtof(json.c_str() + valStart, &endPtr);
    if (endPtr == json.c_str() + valStart) return false;
    outVal = parsed;
    return true;
}

bool extractJsonUintPtr(const std::string& json, const char* key, std::uintptr_t& outVal) noexcept {
    std::string pattern = std::string("\"") + key + "\"";
    auto pos = json.find(pattern);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos + pattern.size());
    if (pos == std::string::npos) return false;
    auto valStart = json.find_first_not_of(" \t\r\n", pos + 1);
    if (valStart == std::string::npos) return false;
    char* endPtr = nullptr;
    unsigned long long parsed = std::strtoull(json.c_str() + valStart, &endPtr, 0);
    if (endPtr == json.c_str() + valStart) return false;
    outVal = static_cast<std::uintptr_t>(parsed);
    return true;
}

bool extractJsonString(const std::string& json, const char* key, std::string& outVal) noexcept {
    std::string pattern = std::string("\"") + key + "\"";
    auto pos = json.find(pattern);
    if (pos == std::string::npos) return false;
    pos = json.find(':', pos + pattern.size());
    if (pos == std::string::npos) return false;
    auto firstQuote = json.find('"', pos + 1);
    if (firstQuote == std::string::npos) return false;
    auto secondQuote = json.find('"', firstQuote + 1);
    if (secondQuote == std::string::npos) return false;
    outVal = json.substr(firstQuote + 1, secondQuote - firstQuote - 1);
    return true;
}

// Detour statis C ABI untuk HudPlayerRenderer::render
void detourHudPlayerRendererRender(
    void* self,
    void* renderContext,
    void* clientInstance,
    void* uiControl,
    int pass,
    McRectangleArea* rectArea
) noexcept {
    PaperDollTouchMod::instance().onHudPlayerRenderDetour(
        self, renderContext, clientInstance, uiControl, pass, rectArea
    );
}

} // namespace

PaperDollTouchMod& PaperDollTouchMod::instance() noexcept {
    static PaperDollTouchMod sInstance;
    return sInstance;
}

std::int64_t PaperDollTouchMod::monotonicMillis() noexcept {
    struct timespec ts {};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<std::int64_t>(ts.tv_sec) * 1000LL +
           static_cast<std::int64_t>(ts.tv_nsec / 1000000LL);
}

bool PaperDollTouchMod::loadConfiguration(const std::string& configPath) noexcept {
    std::ifstream file(configPath, std::ios::in | std::ios::binary);
    if (!file.is_open()) {
        PDT_LOGW("File konfigurasi tidak ditemukan di %s. Menggunakan nilai default aman.", configPath.c_str());
        return false;
    }

    std::ostringstream ss;
    ss << file.rdbuf();
    const std::string content = ss.str();

    extractJsonBool(content, "enabled", mConfig.enabled);
    extractJsonFloat(content, "sensitivityYaw", mConfig.sensitivityYaw);
    extractJsonFloat(content, "sensitivityPitch", mConfig.sensitivityPitch);
    extractJsonBool(content, "invertVertical", mConfig.invertVertical);
    extractJsonFloat(content, "maxPitchDegrees", mConfig.maxPitchDegrees);
    extractJsonBool(content, "resetOnInventoryClose", mConfig.resetOnInventoryClose);
    extractJsonFloat(content, "smoothingFactor", mConfig.smoothingFactor);

    extractJsonFloat(content, "minX", mConfig.normMinX);
    extractJsonFloat(content, "minY", mConfig.normMinY);
    extractJsonFloat(content, "maxX", mConfig.normMaxX);
    extractJsonFloat(content, "maxY", mConfig.normMaxY);

    extractJsonString(content, "expectedMinecraftVersion", mConfig.expectedMinecraftVersion);
    extractJsonBool(content, "verifiedSignaturesReady", mConfig.verifiedSignaturesReady);
    extractJsonString(content, "hudPlayerRendererRenderSig", mConfig.hudPlayerRendererRenderSig);
    extractJsonString(content, "getLocalPlayerFromClientSig", mConfig.getLocalPlayerFromClientSig);
    extractJsonUintPtr(content, "actorRotYawOffset", mConfig.actorRotYawOffset);
    extractJsonUintPtr(content, "actorRotPitchOffset", mConfig.actorRotPitchOffset);
    extractJsonUintPtr(content, "mobBodyYawOffset", mConfig.mobBodyYawOffset);
    extractJsonUintPtr(content, "mobHeadYawOffset", mConfig.mobHeadYawOffset);

    // Clamp parameter konfigurasi agar tetap berada dalam rentang aman
    mConfig.sensitivityYaw = std::clamp(mConfig.sensitivityYaw, 0.05f, 5.0f);
    mConfig.sensitivityPitch = std::clamp(mConfig.sensitivityPitch, 0.0f, 5.0f);
    mConfig.maxPitchDegrees = std::clamp(mConfig.maxPitchDegrees, 0.0f, 85.0f);
    mConfig.smoothingFactor = std::clamp(mConfig.smoothingFactor, 0.05f, 1.0f);

    mState.activeBoundsMinX.store(mConfig.normMinX, std::memory_order_relaxed);
    mState.activeBoundsMinY.store(mConfig.normMinY, std::memory_order_relaxed);
    mState.activeBoundsMaxX.store(mConfig.normMaxX, std::memory_order_relaxed);
    mState.activeBoundsMaxY.store(mConfig.normMaxY, std::memory_order_relaxed);

    return true;
}

bool PaperDollTouchMod::load() {
    PDT_LOGI("Memuat PaperDollTouchMod (Target: Minecraft Bedrock Android %s, ABI: arm64-v8a)...",
             mConfig.expectedMinecraftVersion.c_str());

    // Baca konfigurasi dari folder mod yang diberikan oleh LeviLauncher.
#if PDT_HAS_PL_MOD
    if (auto* nativeMod = ll::mod::NativeMod::current()) {
        const auto configDir = nativeMod->getConfigDir();
        std::error_code ec;
        std::filesystem::create_directories(configDir, ec);
        loadConfiguration((configDir / "config.json").string());
    } else {
        PDT_LOGW("NativeMod::current() belum tersedia; konfigurasi memakai nilai aman default.");
    }
#else
    loadConfiguration("config/config.json");
#endif
    resetTouchAndOrientation(true);
    return true;
}

bool PaperDollTouchMod::tryInstallVerifiedHooks() noexcept {
    // FAIL-SAFE UTAMA:
    // Jangan pernah memasang hook apabila signature dan offset untuk build 26.60
    // belum diverifikasi secara nyata dari binary libminecraftpe.so milik pengguna.
    if (!mConfig.verifiedSignaturesReady ||
        mConfig.hudPlayerRendererRenderSig.empty() ||
        mConfig.getLocalPlayerFromClientSig.empty() ||
        mConfig.actorRotYawOffset == 0 ||
        mConfig.actorRotPitchOffset == 0 ||
        mConfig.mobBodyYawOffset == 0 ||
        mConfig.mobHeadYawOffset == 0) {
        PDT_LOGW(
            "[FAIL-SAFE] Signature/offset biner untuk Minecraft %s belum diisi/diverifikasi di config.json. "
            "Hook ke libminecraftpe.so TIDAK dipasang demi mencegah crash atau memory corruption.",
            mConfig.expectedMinecraftVersion.c_str()
        );
        return false;
    }

#if PDT_HAS_PL_SIG && PDT_HAS_PL_HOOK
    uintptr_t renderAddr = pl::memory::resolveSignature(
        mConfig.hudPlayerRendererRenderSig.c_str(), "libminecraftpe.so"
    );
    uintptr_t getLocalPlayerAddr = pl::memory::resolveSignature(
        mConfig.getLocalPlayerFromClientSig.c_str(), "libminecraftpe.so"
    );

    if (renderAddr == 0 || getLocalPlayerAddr == 0) {
        PDT_LOGE(
            "[FAIL-SAFE] Gagal me-resolve signature pada libminecraftpe.so (renderAddr=0x%zx, getLocalPlayerAddr=0x%zx). "
            "Kemungkinan versi Minecraft bukan %s. Mod dinonaktifkan secara aman.",
            static_cast<size_t>(renderAddr),
            static_cast<size_t>(getLocalPlayerAddr),
            mConfig.expectedMinecraftVersion.c_str()
        );
        return false;
    }

    mHudPlayerRenderTarget = reinterpret_cast<void*>(renderAddr);
    mGetLocalPlayerFn = reinterpret_cast<void*>(getLocalPlayerAddr);

    int hookStatus = pl::memory::hook(
        mHudPlayerRenderTarget,
        reinterpret_cast<void*>(&detourHudPlayerRendererRender),
        &mHudPlayerRenderOriginal,
        pl::memory::HookPriority::Normal
    );

    if (hookStatus != 0 || mHudPlayerRenderOriginal == nullptr) {
        PDT_LOGE("[FAIL-SAFE] pl::memory::hook gagal dengan kode %d. Membatalkan aktivasi hook.", hookStatus);
        mHudPlayerRenderTarget = nullptr;
        mHudPlayerRenderOriginal = nullptr;
        mGetLocalPlayerFn = nullptr;
        return false;
    }

    mState.hookInstalled.store(true, std::memory_order_release);
    PDT_LOGI("Hook HudPlayerRenderer::render berhasil dipasang pada 0x%zx.", static_cast<size_t>(renderAddr));
    return true;
#else
    PDT_LOGW("[FAIL-SAFE] Header pl/memory/Hook.hpp atau pl/memory/Signature.hpp tidak aktif saat kompilasi.");
    return false;
#endif
}

void PaperDollTouchMod::removeHooks() noexcept {
    if (mState.hookInstalled.load(std::memory_order_acquire) && mHudPlayerRenderTarget != nullptr) {
#if PDT_HAS_PL_HOOK
        pl::memory::unhook(
            mHudPlayerRenderTarget,
            reinterpret_cast<void*>(&detourHudPlayerRendererRender)
        );
#endif
        PDT_LOGI("Hook HudPlayerRenderer::render telah dilepas.");
    }
    mState.hookInstalled.store(false, std::memory_order_release);
    mHudPlayerRenderTarget = nullptr;
    mHudPlayerRenderOriginal = nullptr;
    mGetLocalPlayerFn = nullptr;
}

bool PaperDollTouchMod::enable() {
    if (!mConfig.enabled) {
        PDT_LOGI("PaperDollTouch dinonaktifkan melalui config.json.");
        return true;
    }

    resetTouchAndOrientation(true);
    tryInstallVerifiedHooks();

    // Daftarkan callback input hanya sekali sepanjang umur proses
    // karena Preloader Input API mungkin tidak menyediakan fungsi unregister callback
    if (!mInputCallbackRegistered) {
#if PDT_HAS_PL_INPUT
        pl::input::registerTouchCallback([](const pl::input::TouchEvent& event) -> bool {
            return PaperDollTouchMod::instance().onTouchEvent(
                event.action, event.pointerId, event.x, event.y
            );
        });
#endif
        mInputCallbackRegistered = true;
    }

    mState.modActive.store(true, std::memory_order_release);
    PDT_LOGI("PaperDollTouchMod diaktifkan (Status Hook Native: %s).",
             mState.hookInstalled.load(std::memory_order_acquire) ? "AKTIF" : "MODE DIAGNOSTIK AMAN");
    return true;
}

bool PaperDollTouchMod::disable() {
    mState.modActive.store(false, std::memory_order_release);
    resetTouchAndOrientation(true);
    removeHooks();
    PDT_LOGI("PaperDollTouchMod dinonaktifkan dan state orientasi dipulihkan.");
    return true;
}

bool PaperDollTouchMod::unload() {
    disable();
    PDT_LOGI("PaperDollTouchMod dibersihkan (unloaded).");
    return true;
}

void PaperDollTouchMod::resetTouchAndOrientation(bool clearAngles) noexcept {
    mState.activePointerId.store(-1, std::memory_order_relaxed);
    mState.lastTouchX.store(0.0f, std::memory_order_relaxed);
    mState.lastTouchY.store(0.0f, std::memory_order_relaxed);
    if (clearAngles) {
        mState.targetYawOffset.store(0.0f, std::memory_order_relaxed);
        mState.targetPitchOffset.store(0.0f, std::memory_order_relaxed);
        mState.currentYawOffset.store(0.0f, std::memory_order_relaxed);
        mState.currentPitchOffset.store(0.0f, std::memory_order_relaxed);
    }
}

bool PaperDollTouchMod::isPointInsidePreviewBounds(float x, float y) const noexcept {
    const float sw = std::max(1.0f, mState.screenWidth.load(std::memory_order_relaxed));
    const float sh = std::max(1.0f, mState.screenHeight.load(std::memory_order_relaxed));

    const float nx = x / sw;
    const float ny = y / sh;

    const float minX = mState.activeBoundsMinX.load(std::memory_order_relaxed);
    const float minY = mState.activeBoundsMinY.load(std::memory_order_relaxed);
    const float maxX = mState.activeBoundsMaxX.load(std::memory_order_relaxed);
    const float maxY = mState.activeBoundsMaxY.load(std::memory_order_relaxed);

    return (nx >= minX && nx <= maxX && ny >= minY && ny <= maxY);
}

bool PaperDollTouchMod::onTouchEvent(int action, int pointerId, float x, float y) noexcept {
    // 1. Jika mod sedang nonaktif atau hook native tidak terpasang, keluar seketika (zero overhead)
    if (!mState.modActive.load(std::memory_order_acquire) ||
        !mState.hookInstalled.load(std::memory_order_acquire)) {
        return false;
    }

    // Kalibrasi adaptif batas bawah dimensi layar fisik tanpa sistem call berat
    float currentSw = mState.screenWidth.load(std::memory_order_relaxed);
    float currentSh = mState.screenHeight.load(std::memory_order_relaxed);
    if (x > currentSw) mState.screenWidth.store(x, std::memory_order_relaxed);
    if (y > currentSh) mState.screenHeight.store(y, std::memory_order_relaxed);

    // 2. Periksa apakah layar preview inventory masih dirender dalam rentang waktu aktif
    const std::int64_t nowMs = monotonicMillis();
    const std::int64_t lastRenderMs = mState.lastInventoryRenderMs.load(std::memory_order_acquire);
    const bool inventoryOpen = (lastRenderMs > 0) && ((nowMs - lastRenderMs) <= kInventoryRenderTimeoutMs);

    if (!inventoryOpen) {
        if (mState.inventoryPreviewVisible.exchange(false, std::memory_order_acq_rel)) {
            resetTouchAndOrientation(mConfig.resetOnInventoryClose);
        }
        return false;
    }

    const int maskedAction = action & AMOTION_EVENT_ACTION_MASK;
    const int trackedPointer = mState.activePointerId.load(std::memory_order_relaxed);

    switch (maskedAction) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN: {
            // Hanya kunci pointerId jika belum ada jari aktif DAN titik awal sentuhan
            // benar-benar berada di dalam area panel preview paper doll.
            // Jika sentuhan dimulai pada slot item/tombol armor, jangan pernah mengintersepnya.
            if (trackedPointer == -1 && isPointInsidePreviewBounds(x, y)) {
                mState.activePointerId.store(pointerId, std::memory_order_relaxed);
                mState.lastTouchX.store(x, std::memory_order_relaxed);
                mState.lastTouchY.store(y, std::memory_order_relaxed);
            }
            break;
        }

        case AMOTION_EVENT_ACTION_MOVE: {
            // Abaikan semua gerakan dari pointerId yang tidak memulai sentuhan di area paper doll
            if (trackedPointer != -1 && pointerId == trackedPointer) {
                const float prevX = mState.lastTouchX.load(std::memory_order_relaxed);
                const float prevY = mState.lastTouchY.load(std::memory_order_relaxed);

                const float deltaX = x - prevX;
                const float deltaY = y - prevY;

                mState.lastTouchX.store(x, std::memory_order_relaxed);
                mState.lastTouchY.store(y, std::memory_order_relaxed);

                // Abaikan noise mikro di bawah 0.25 piksel
                if (std::fabs(deltaX) > 0.25f || std::fabs(deltaY) > 0.25f) {
                    float yaw = mState.targetYawOffset.load(std::memory_order_relaxed);
                    float pitch = mState.targetPitchOffset.load(std::memory_order_relaxed);

                    // Geser kiri/kanan memutar orientasi horizontal
                    yaw -= deltaX * mConfig.sensitivityYaw;
                    // Normalisasi sudut ke rentang [-180.0f, 180.0f]
                    yaw = std::remainder(yaw, 360.0f);

                    // Geser atas/bawah mengatur orientasi vertikal dengan batas aman
                    const float pitchSign = mConfig.invertVertical ? -1.0f : 1.0f;
                    pitch += (deltaY * pitchSign) * mConfig.sensitivityPitch;
                    pitch = std::clamp(pitch, -mConfig.maxPitchDegrees, mConfig.maxPitchDegrees);

                    mState.targetYawOffset.store(yaw, std::memory_order_relaxed);
                    mState.targetPitchOffset.store(pitch, std::memory_order_relaxed);
                }
            }
            break;
        }

        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP:
        case AMOTION_EVENT_ACTION_CANCEL: {
            if (trackedPointer != -1 && pointerId == trackedPointer) {
                mState.activePointerId.store(-1, std::memory_order_relaxed);
            }
            break;
        }

        default:
            break;
    }

    // Kembalikan false agar event sentuhan tetap diteruskan ke sistem UI Minecraft
    // tanpa merusak state touch controller internal
    return false;
}

void PaperDollTouchMod::onHudPlayerRenderDetour(
    void* self,
    void* renderContext,
    void* clientInstance,
    void* uiControl,
    int pass,
    McRectangleArea* rectArea
) noexcept {
    auto originalFn = reinterpret_cast<HudPlayerRendererRenderFn>(mHudPlayerRenderOriginal);
    if (originalFn == nullptr) {
        return;
    }

    // Jika mod dinonaktifkan atau parameter tidak lengkap, langsung panggil fungsi asli
    if (!mState.modActive.load(std::memory_order_acquire) ||
        clientInstance == nullptr ||
        rectArea == nullptr ||
        mGetLocalPlayerFn == nullptr) {
        originalFn(self, renderContext, clientInstance, uiControl, pass, rectArea);
        return;
    }

    // Bedakan paper doll inventory dari paper doll kecil di pojok HUD in-game
    const float rectWidth = rectArea->x1 - rectArea->x0;
    const float rectHeight = rectArea->y1 - rectArea->y0;
    const bool isInventoryPanel = (rectWidth >= kMinInventoryPreviewWidthUi) &&
                                  (rectHeight >= kMinInventoryPreviewHeightUi) &&
                                  (rectArea->x0 > 12.0f);

    if (!isInventoryPanel) {
        originalFn(self, renderContext, clientInstance, uiControl, pass, rectArea);
        return;
    }

    // Tandai bahwa preview karakter inventory sedang aktif dirender pada frame ini
    mState.lastInventoryRenderMs.store(monotonicMillis(), std::memory_order_release);
    mState.inventoryPreviewVisible.store(true, std::memory_order_release);

    // Hitung interpolasi ringan (exponential smoothing) tanpa thread tambahan
    const float targetYaw = mState.targetYawOffset.load(std::memory_order_relaxed);
    const float targetPitch = mState.targetPitchOffset.load(std::memory_order_relaxed);
    float curYaw = mState.currentYawOffset.load(std::memory_order_relaxed);
    float curPitch = mState.currentPitchOffset.load(std::memory_order_relaxed);

    const float alpha = mConfig.smoothingFactor;
    curYaw += (targetYaw - curYaw) * alpha;
    curPitch += (targetPitch - curPitch) * alpha;

    mState.currentYawOffset.store(curYaw, std::memory_order_relaxed);
    mState.currentPitchOffset.store(curPitch, std::memory_order_relaxed);

    // Jika belum ada perubahan sudut yang berarti, panggil fungsi asli tanpa menyentuh state Actor
    if (std::fabs(curYaw) < 0.01f && std::fabs(curPitch) < 0.01f) {
        originalFn(self, renderContext, clientInstance, uiControl, pass, rectArea);
        return;
    }

    auto getLocalPlayer = reinterpret_cast<GetLocalPlayerFn>(mGetLocalPlayerFn);
    void* localPlayer = getLocalPlayer(clientInstance);
    if (localPlayer == nullptr) {
        originalFn(self, renderContext, clientInstance, uiControl, pass, rectArea);
        return;
    }

    // Scoped Save-and-Restore pada orientasi LocalPlayer khusus selama eksekusi HudPlayerRenderer::render
    auto* basePtr = static_cast<std::uint8_t*>(localPlayer);
    auto* actorYawPtr = reinterpret_cast<float*>(basePtr + mConfig.actorRotYawOffset);
    auto* actorPitchPtr = reinterpret_cast<float*>(basePtr + mConfig.actorRotPitchOffset);
    auto* bodyYawPtr = reinterpret_cast<float*>(basePtr + mConfig.mobBodyYawOffset);
    auto* headYawPtr = reinterpret_cast<float*>(basePtr + mConfig.mobHeadYawOffset);

    const float savedActorYaw = *actorYawPtr;
    const float savedActorPitch = *actorPitchPtr;
    const float savedBodyYaw = *bodyYawPtr;
    const float savedHeadYaw = *headYawPtr;

    *actorYawPtr = savedActorYaw + curYaw;
    *bodyYawPtr = savedBodyYaw + curYaw;
    *headYawPtr = savedHeadYaw + curYaw;
    *actorPitchPtr = std::clamp(savedActorPitch + curPitch, -mConfig.maxPitchDegrees, mConfig.maxPitchDegrees);

    // Render paper doll menggunakan pipeline asli Minecraft (skin, armor, held item tetap utuh)
    originalFn(self, renderContext, clientInstance, uiControl, pass, rectArea);

    // Pulihkan orientasi asli LocalPlayer seketika agar arah pandang di dunia tidak berubah
    *actorYawPtr = savedActorYaw;
    *actorPitchPtr = savedActorPitch;
    *bodyYawPtr = savedBodyYaw;
    *headYawPtr = savedHeadYaw;
}

} // namespace paperdoll

// Entry point registrasi mod sesuai standar Preloader Android / LeviLaunchroid
#if PDT_HAS_PL_MOD
PL_REGISTER_MOD(paperdoll::PaperDollTouchMod, paperdoll::PaperDollTouchMod::instance())
#else
extern "C" [[gnu::visibility("default")]] void LeviMod_OnLoad() {
    paperdoll::PaperDollTouchMod::instance().load();
    paperdoll::PaperDollTouchMod::instance().enable();
}
#endif
